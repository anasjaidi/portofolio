/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   syntax_utile.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zmaziane <zmaziane@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/28 19:03:43 by zmaziane          #+#    #+#             */
/*   Updated: 2022/07/01 19:33:20 by zmaziane         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

t_list	*get_right(t_list *head)
{
	if (head->next && head->next->type == 6)
	{
		if (head->next->next)
			return (head->next->next);
		else
			return (NULL);
	}
	else
		return (head->next);
}

t_list	*get_left(t_list *head)
{
	if (head->prev && head->prev->type == 6)
	{
		if (head->prev->prev)
			return (head->prev->prev);
		else
			return (NULL);
	}
	else
		return (head->prev);
}

int	check_red(t_list *head)
{
	t_list	*t;

	t = get_right(head);
	if (!t)
		return (0);
	if ((!(t->type >= 5 && t->type <= 8) && (t->type != 0)))
		return (0);
	return (1);
}
