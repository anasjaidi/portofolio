<?php

header('Location: auth/');
